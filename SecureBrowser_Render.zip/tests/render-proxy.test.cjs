'use strict';
const {test, before, after} = require('node:test');
const assert = require('node:assert/strict');
const {Readable} = require('node:stream');
const axios = require('axios');
// Test at small limits while still checking streaming beyond the old 5.5 MB cap.
process.env.PROXY_MAX_REWRITE_MB = '1';
process.env.PROXY_MAX_STREAM_MB = '8';
process.env.PROXY_TIMEOUT_MS = '1000';
process.env.PROXY_MAX_CONCURRENT = '2';
const app = require('../server');
const {toProxyUrl, assertSafeTarget, rewriteHtml, isPrivateIp} = app._internals;
let server, origin, calls = [];
const actualRequest = axios.request;
const reply = (data, type='text/html', status=200, headers={}) => ({status, headers:{'content-type':type,...headers}, data:Readable.from([Buffer.from(data)])});
before(async () => {
  server = app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  origin = 'http://127.0.0.1:' + server.address().port;
  axios.request = async options => {
    calls.push(options);
    const u = new URL(options.url);
    if (u.pathname === '/slow') return new Promise((resolve,reject) => options.signal.addEventListener('abort',()=>reject(Object.assign(new Error('Canceled'),{code:'ERR_CANCELED'})),{once:true}));
    if (u.pathname === '/redirect') return reply('', 'text/html', 302, {location:'/next'});
    if (u.pathname === '/private-redirect') return reply('', 'text/html', 302, {location:'http://127.0.0.1/private'});
    if (u.pathname === '/large') return reply(Buffer.alloc(6*1024*1024, 7),'application/octet-stream');
    if (u.pathname === '/too-large') return reply('x'.repeat(1024*1024+1));
    if (u.pathname === '/range') return reply('clip','video/mp4',206,{'content-range':'bytes 0-3/100','accept-ranges':'bytes'});
    if (u.pathname === '/range.css' && options.headers.Range) return reply('p{','text/css',206,{'content-range':'bytes 0-1/20'});
    if (u.pathname === '/range.css') return reply('p{background:url(/img.png)}','text/css');
    if (u.pathname === '/main.js') return reply('import "./dep.js";', 'application/javascript');
    if (u.pathname === '/empty') return reply('', 'text/plain', 204);
    if (u.pathname === '/echo') return reply(options.data || '', 'application/json');
    return reply('<title>Fixture</title><link rel="stylesheet" href="/main.css"><a href="next">Next</a><script type="module">import "./main.js"</script>', 'text/html', 200, {
      'x-frame-options':'DENY', 'content-security-policy':"frame-ancestors 'none'", 'set-cookie':'secret=1',
      'access-control-allow-origin':'https://upstream.example', connection:'keep-alive, x-hop', 'x-hop':'remove-me'
    });
  };
});
after(async () => { axios.request = actualRequest; server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
const proxy = (path, options) => fetch(origin+'/proxy?url='+encodeURIComponent('https://example.com'+path), options);

test('UI and Render health check are served from the same service', async () => {
  assert.deepEqual(await (await fetch(origin+'/healthz')).json(), {status:'ok'});
  const html = await (await fetch(origin)).text();
  assert.match(html, /const PROXY_BASE=location.origin/);
  assert.doesNotMatch(html, /netlify\.app/);
});
test('HTML rewrites assets/modules and preserves isolation and CORS', async () => {
  const r = await proxy('/page', {headers:{Origin:'null'}});
  assert.equal(r.status,200);
  assert.equal(r.headers.get('x-frame-options'),null);
  assert.equal(r.headers.get('set-cookie'),null);
  assert.equal(r.headers.get('x-hop'),null);
  assert.equal(r.headers.get('access-control-allow-origin'),'null');
  assert.match(r.headers.get('content-security-policy'),/^sandbox /);
  assert.doesNotMatch(r.headers.get('content-security-policy'),/allow-same-origin/);
  const html = await r.text();
  assert.ok(html.includes(toProxyUrl('/main.css','https://example.com/page')));
  assert.ok(html.includes(toProxyUrl('./main.js','https://example.com/page')));
  assert.equal(calls.at(-1).proxy,false);
  assert.equal(calls.at(-1).maxRedirects,0);
});
test('6 MB files stream completely beyond the previous response cap', async () => {
  const r = await proxy('/large');
  assert.equal(r.status,200);
  const bytes = new Uint8Array(await r.arrayBuffer());
  assert.equal(bytes.length,6*1024*1024);
  assert.equal(bytes.at(-1),7);
});
test('range response retains status and Content-Range for media seeking', async () => {
  const r = await proxy('/range',{headers:{Range:'bytes=0-3'}});
  assert.equal(r.status,206);
  assert.equal(r.headers.get('content-range'),'bytes 0-3/100');
  assert.equal(await r.text(),'clip');
  assert.equal(calls.at(-1).headers.Range,'bytes=0-3');
});
test('partial CSS is refetched completely before rewriting', async () => {
  const r = await proxy('/range.css',{headers:{Range:'bytes=0-1'}});
  assert.equal(r.status,200);
  assert.equal(r.headers.get('content-range'),null);
  assert.match(await r.text(),/proxy\?url=/);
  assert.equal(calls.at(-1).headers.Range,undefined);
});
test('module dependencies use their original script origin', async () => {
  const r = await proxy('/main.js');
  assert.ok((await r.text()).includes(toProxyUrl('./dep.js','https://example.com/main.js')));
});
test('redirects remain proxied and private destinations are rejected', async () => {
  const r = await proxy('/redirect',{redirect:'manual'});
  assert.equal(r.status,302);
  assert.equal(r.headers.get('location'),toProxyUrl('/next','https://example.com/redirect'));
  assert.equal((await proxy('/private-redirect',{redirect:'manual'})).status,403);
});
test('HEAD and 204 do not attempt HTML rewriting', async () => {
  const r = await proxy('/page',{method:'HEAD'});
  assert.equal(r.status,200); assert.equal(await r.text(),'');
  assert.equal((await proxy('/empty')).status,204);
});
test('POST bodies are forwarded without browser cookies or authorization', async () => {
  const r = await proxy('/echo',{method:'POST',headers:{'Content-Type':'application/json',Cookie:'private=1',Authorization:'Bearer private'},body:'{"a":1}'});
  assert.equal(await r.text(),'{"a":1}');
  assert.equal(calls.at(-1).headers.Cookie,undefined);
  assert.equal(calls.at(-1).headers.Authorization,undefined);
});
test('bounded rewrites fail with a usable error and no stale range headers', async () => {
  const r = await proxy('/too-large');
  assert.equal(r.status,413);
  assert.match(await r.text(),/configured rewrite size limit/);
  assert.equal(r.headers.get('cache-control'),'no-store');
});
test('deadline returns 504', async () => {
  const r = await proxy('/slow');
  assert.equal(r.status,504);
  assert.match(await r.text(),/too long/);
});
test('preflight and existing summary content gate still work', async () => {
  const r = await proxy('/page',{method:'OPTIONS',headers:{Origin:'null'}});
  assert.equal(r.status,204);
  assert.equal(r.headers.get('access-control-allow-origin'),'null');
  const summary = await (await fetch(origin+'/api/summary?q=hardcore%20porn')).json();
  assert.equal(summary.suppressed,true);
});
test('unsafe targets fail before any network request', async () => {
  for (const target of ['http://127.0.0.1/','http://[::1]/','http://10.0.0.1/','http://localhost/','file:///secret','https://user:pass@example.com/']) {
    assert.throws(()=>assertSafeTarget(target));
    const count=calls.length;
    const r=await fetch(origin+'/proxy?url='+encodeURIComponent(target));
    assert.ok(r.status>=400 && r.status<500);
    assert.equal(calls.length,count);
  }
  assert.equal(isPrivateIp('169.254.169.254'),true);
  assert.equal(isPrivateIp('2606:4700:4700::1111'),false);
});
test('URL resolution and GET forms survive rewriting', () => {
  assert.equal(toProxyUrl('../x#part','https://example.com/a/b'),'/proxy?url=https%3A%2F%2Fexample.com%2Fx#part');
  const html = rewriteHtml('<base href="https://example.com/docs/"><form action="search"><input name="q"></form>', 'https://example.com/');
  assert.match(html,/name="__pt" value="https:\/\/example.com\/docs\/search"/);
});
test('sandbox storage fallback is document-local and leaves usable storage intact', () => {
  const {JSDOM} = require('jsdom');
  const dom = new JSDOM('', {url:'https://proxy.example/',runScripts:'outside-only'});
  const second = new JSDOM('', {url:'https://proxy.example/',runScripts:'outside-only'});
  try {
    for (const name of ['localStorage','sessionStorage']) {
      Object.defineProperty(dom.window,name,{configurable:true,get(){throw new Error('SecurityError');}});
    }
    Object.defineProperty(dom.window.document,'cookie',{configurable:true,get(){throw new Error('SecurityError');}});
    dom.window.eval(app._internals.buildShim('https://example.com/'));
    dom.window.localStorage.setItem('theme','dark');
    assert.equal(dom.window.localStorage.getItem('theme'),'dark');
    assert.equal(dom.window.sessionStorage.getItem('theme'),null);
    dom.window.document.cookie='setting=1';
    assert.equal(dom.window.document.cookie,'setting=1');
    dom.window.document.cookie='setting=; Max-Age=0';
    assert.equal(dom.window.document.cookie,'');
    second.window.localStorage.setItem('original','kept');
    second.window.eval(app._internals.buildShim('https://example.com/'));
    assert.equal(second.window.localStorage.getItem('theme'),null);
    assert.equal(second.window.localStorage.getItem('original'),'kept');
  } finally { dom.window.close(); second.window.close(); }
});
